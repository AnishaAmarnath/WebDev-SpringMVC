package springmvc.model;

import java.io.File;
import java.io.Serializable;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "application")
public class Application implements Serializable{
	@Id
	Integer id;
	String Address;
	public String getAddress() {
		return Address;
	}

	public CsUsers getUsers() {
		return users;
	}

	public jobPosition getJobs() {
		return jobs;
	}

	public void setAddress(String address) {
		Address = address;
	}

	public void setUsers(CsUsers users) {
		this.users = users;
	}

	public void setJobs(jobPosition jobs) {
		this.jobs = jobs;
	}

	String currentJob;
	String institution;
	Integer year;
	@Column(name = "cv")
	File cir_vitae;
	@Column(name = "rs")
	File res_statmnt;
	@Column(name = "ts")
	File teach_statmnt;

	@ManyToOne
	CsUsers users;

	@ManyToOne
	jobPosition jobs;

	public Integer getId() {
		return id;
	}

	public String getCurrentJob() {
		return currentJob;
	}

	public String getInstitution() {
		return institution;
	}

	public Integer getYear() {
		return year;
	}

	public File getCir_vitae() {
		return cir_vitae;
	}

	public File getRes_statmnt() {
		return res_statmnt;
	}

	public File getTeach_statmnt() {
		return teach_statmnt;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public void setCurrentJob(String currentJob) {
		this.currentJob = currentJob;
	}

	public void setInstitution(String institution) {
		this.institution = institution;
	}

	public void setYear(Integer year) {
		this.year = year;
	}

	public void setCir_vitae(File cir_vitae) {
		this.cir_vitae = cir_vitae;
	}

	public void setRes_statmnt(File res_statmnt) {
		this.res_statmnt = res_statmnt;
	}

	public void setTeach_statmnt(File teach_statmnt) {
		this.teach_statmnt = teach_statmnt;
	}

}
