package springmvc.model;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="EducationClass")
public class EducationClass implements Serializable {
	@Id
	Integer id;
	String degree;
	 String university;
	 Integer completion_year;
	 String phone;
	 @ManyToOne
	 Application application;
	 
	public Integer getId() {
		return id;
	}
	public Application getApplication() {
		return application;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public void setApplication(Application application) {
		this.application = application;
	}
	public String getDegree() {
		return degree;
	}
	public String getUniversity() {
		return university;
	}
	public Integer getCompletion_year() {
		return completion_year;
	}
	public void setDegree(String degree) {
		this.degree = degree;
	}
	public void setUniversity(String university) {
		this.university = university;
	}
	public void setCompletion_year(Integer completion_year) {
		this.completion_year = completion_year;
	}
	 
}
