package springmvc.model.dao;

import java.util.List;
import springmvc.model.jobPosition;

public interface jobPositionDao {

	jobPosition getjobPosition( Integer id );

    List<jobPosition> getjobPosition();

}
