package springmvc.model.dao;

import java.util.List;

import springmvc.model.ReviewProcess;

public interface ReviewProcessDao {

	ReviewProcess getReviewers( Integer id );

    List<ReviewProcess> getReviewers();

}
