package springmvc.model.dao.jpa;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import springmvc.model.jobPosition;
import springmvc.model.dao.jobPositionDao;

@Repository
public class jobPositionImpl implements jobPositionDao {

    @PersistenceContext
    private EntityManager entityManager;

    @Override
    public jobPosition getjobPosition( Integer id )
    {
        return entityManager.find( jobPosition.class, id );
    }

    @Override
    public List<jobPosition> getjobPosition()
    {
        return entityManager.createQuery( "from jobPosition order by id", jobPosition.class )
            .getResultList();
    }

}