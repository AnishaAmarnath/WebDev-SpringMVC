package springmvc.model.dao.jpa;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import springmvc.model.ReviewProcess;
import springmvc.model.dao.ReviewProcessDao;

@Repository
public class ReviewProcessDaoImpl implements ReviewProcessDao {

    @PersistenceContext
    private EntityManager entityManager;

    @Override
    public ReviewProcess getReviewers( Integer id )
    {
        return entityManager.find( ReviewProcess.class, id );
    }

    

	@Override
	public List<ReviewProcess> getReviewers() {
		// TODO Auto-generated method stub
		return entityManager.createQuery( "SELECT committee from ReviewProcess order by id", ReviewProcess.class )
	            .getResultList();
	}

}