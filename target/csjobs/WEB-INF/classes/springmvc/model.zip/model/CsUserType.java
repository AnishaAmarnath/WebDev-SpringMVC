package springmvc.model;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "csusertype")
public class CsUserType implements Serializable {
  
	@Id
	Integer type_id;
	String type;
	public Integer getType_id() {
		return type_id;
	}
	public String getType() {
		return type;
	}
	public void setType_id(Integer type_id) {
		this.type_id = type_id;
	}
	public void setType(String type) {
		this.type = type;
	}
	
}
