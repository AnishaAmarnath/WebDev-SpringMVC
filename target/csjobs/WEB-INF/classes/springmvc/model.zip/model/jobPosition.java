package springmvc.model;

import java.io.Serializable;
import java.util.Calendar;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name = "jobPosition")
public class jobPosition implements Serializable {
	@Id
	Integer id;
	String title;
	String description;
	Calendar OpenDate;
	Calendar CloseDate;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public String getDescription() {
		return description;
	}
	public Calendar getOpenDate() {
		return OpenDate;
	}
	public Calendar getCloseDate() {
		return CloseDate;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public void setOpenDate(Calendar openDate) {
		OpenDate = openDate;
	}
	public void setCloseDate(Calendar closeDate) {
		CloseDate = closeDate;
	}
	
}
