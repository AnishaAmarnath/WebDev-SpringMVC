package springmvc.model;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="reviewprocess")
public class ReviewProcess implements Serializable {
	@Id
	Integer id;
	@ManyToMany
	List<Application> applications;
	@ManyToMany
	List<CsUsers> reviewers;
	@ManyToOne
	jobPosition jobs;
	@ManyToOne
	ReviewerCommittee committee;
	String comments;
	Integer ranking;
	public Integer getId() {
		return id;
	}
	
	public List<CsUsers> getReviewers() {
		return reviewers;
	}
	public ReviewerCommittee getCommittee() {
		return committee;
	}
	public String getComments() {
		return comments;
	}
	
	public void setId(Integer id) {
		this.id = id;
	}
	
	public void setReviewers(List<CsUsers> reviewers) {
		this.reviewers = reviewers;
	}
	public void setCommittee(ReviewerCommittee committee) {
		this.committee = committee;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	
	
		
}
